package address.model;

// 도메인 범위를 지정할 때 사용
public enum GroupType {
	친구,회사,학교,가족;
}

package address;


import address.dao.MemberDao;
import address.gui.MainFrame;
import address.model.GroupType;

public class AddressApp {
	
	public static void main(String[] args) {
		// System.out.println(GroupType.values());
		new MainFrame();
	}

}
